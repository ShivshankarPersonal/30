angular.module("dashboard")
    .controller("teamMembersWeeklyWorkflowStatusController", function () {
        var margin = {top: 20, right: 20, bottom: 50, left: 40},
            width = $('#teamMembersWeeklyWorkflowStatusChart').width() - margin.left - margin.right,
            height = $('#weeklyWorkflowStatusChart').parent().height() - margin.top - margin.bottom - 58;
        var x = d3.scaleBand()
            .range([0, width])
            .padding(0.6);
        var y = d3.scaleLinear()
            .range([height, 0]);
        var svg = d3.select("#teamMembersWeeklyWorkflowStatusChart").append("svg")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
            .append("g")
            .attr("transform",
                "translate(" + margin.left + "," + margin.top + ")");
        d3.csv("data/teamMembersWeeklyWorkflowStatusChart.csv", function (error, data) {
            if (error) throw error;
            data.forEach(function (d) {
                d.complete = +d.complete;
            });
            x.domain(data.map(function (d) {
                return d.teamMember;
            }));
            y.domain([0, d3.max(data, function (d) {
                return d.complete;
            })]);
            svg.selectAll(".bar")
                .data(data)
                .enter().append("rect")
                .attr("class", "bar")
                .attr("x", function (d) {
                    return x(d.teamMember);
                })
                .attr("width", x.bandwidth())
                .attr("y", function (d) {
                    return y(d.complete);
                })
                .attr("height", function (d) {
                    return height - y(d.complete);
                })
                .style("fill", function (d) {
                    return d.color;
                });
            svg.append("g")
                .attr("transform", "translate(0," + height + ")")
                .call(d3.axisBottom(x))
            svg.append("text")
                .attr("transform",
                    "translate(" + (width / 2) + " ," +
                    (height + margin.top + 20) + ")")
                .style("text-anchor", "middle")
                .text("My Team Members");
            svg.append("g")
                .call(d3.axisLeft(y))
            svg.append("text")
                .attr("transform", "rotate(-90)")
                .attr("y", 0 - margin.left)
                .attr("x", 0 - (height / 2))
                .attr("dy", "1em")
                .style("text-anchor", "middle")
                .text("Workflow Complete (%)");
        });
    });