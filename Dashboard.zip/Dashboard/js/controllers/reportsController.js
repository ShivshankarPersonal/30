angular.module("dashboard")
    .controller("reportsController", function ($scope, $state, dashboardFactory) {
        dashboardFactory.fetchData('invoices').then(function (data) {
            $scope.invoicesList = data;
        }, function (data) {
            console.error("Unable to Fetch Invoices List Records")
        });
    });