angular.module("dashboard")
    .controller("homeController", function ($scope, $state, dashboardFactory) {
        dashboardFactory.fetchData('toDoList').then(function (data) {
            $scope.todoItemList = data;
        }, function (data) {
            console.error("Unable to Fetch To Do List Records")
        });
        dashboardFactory.fetchData('clients').then(function (data) {
            $scope.clientsList = data;
        }, function (data) {
            console.error("Unable to Fetch Clients List Records")
        });
    });