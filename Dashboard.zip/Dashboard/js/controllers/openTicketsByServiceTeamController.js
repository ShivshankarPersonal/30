angular.module("dashboard")
    .controller("openTicketsByServiceTeamController", function () {
        var margin = {top: 20, right: 20, bottom: 60, left: 40},
            width = $('#openTicketsByServiceTeam').width() - margin.left - margin.right,
            height = $('#openTicketsByServiceTeam').width() - margin.top - margin.bottom - 50;
        var x = d3.scaleBand()
            .range([0, width])
            .padding(0.5);
        var y = d3.scaleLinear()
            .range([height, 0]);
        var svg = d3.select("#openTicketsByServiceTeam").append("svg")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
            .append("g")
            .attr("transform",
                "translate(" + margin.left + "," + margin.top + ")");
        d3.csv("data/openTicketsByServiceTeam.csv", function (error, data) {
            if (error) throw error;
            data.forEach(function (d) {
                d.revenue = +d.revenue;
            });
            x.domain(data.map(function (d) {
                return d.apTeam;
            }));
            y.domain([0, d3.max(data, function (d) {
                return d.revenue;
            })]);
            svg.selectAll(".bar")
                .data(data)
                .enter().append("rect")
                .attr("class", "bar")
                .attr("x", function (d) {
                    return x(d.apTeam);
                })
                .attr("width", x.bandwidth())
                .attr("y", function (d) {
                    return y(d.revenue);
                })
                .attr("height", function (d) {
                    return height - y(d.revenue);
                })
                .style("fill", function (d) {
                    return "rgb(194,194,194)";
                });
            svg.append("g")
                .attr("transform", "translate(0," + height + ")")
                .call(d3.axisBottom(x));
            svg.append("text")
                .attr("transform",
                    "translate(" + (width / 2) + " ," +
                    (height + margin.top + 20) + ")")
                .style("text-anchor", "middle")
                .text("AP Team");
            svg.append("g")
                .call(d3.axisLeft(y)
                    .tickFormat(d3.format(".0s")));
            svg.append("text")
                .attr("transform", "rotate(-90)")
                .attr("y", 0 - margin.left)
                .attr("x", 0 - (height / 2))
                .attr("dy", "1em")
                .style("text-anchor", "middle")
                .text("Actual Revenue");
        });
    });